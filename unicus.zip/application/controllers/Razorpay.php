<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @package Razorpay :  CodeIgniter Razorpay Gateway
 *
 * @author Olympiad Success Team
 *
 * @email  info@Olympiad Success.com
 *   
 * Description of Razorpay Controller
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Razorpay extends CI_Controller {
    // construct
    // public function __construct() {
    //     parent::__construct();   
    //     $this->load->model('Site', 'site');     
    // }
    // index page
    // public function index() {
    //     $data['title'] = 'Razorpay | Olympiad Success';  
    //     $data['productInfo'] = $this->site->getProduct();           
    //     $this->load->view('razorpay/index', $data);
    // }
    
    // checkout page
    public function checkout($id) {
        $data['title'] = 'Checkout payment | CREST Olympiads';  
        // $this->site->setProductID($id);
        // $data['itemInfo'] = $this->site->getProductDetails(); 
        $data['return_url'] = site_url().'razorpay/callback';
        $data['surl'] = site_url().'razorpay/success';
        $data['furl'] = site_url().'razorpay/failed';
        $data['currency_code'] = 'INR';
        $this->load->view('razorpay/checkout', $data);
    }

    // initialized cURL Request
    private function get_curl_handle($payment_id, $amount)  {
        $url = 'https://api.razorpay.com/v1/payments/'.$payment_id.'/capture';
        $key_id = RAZOR_KEY_ID;
        $key_secret = RAZOR_KEY_SECRET;
        $fields_string = "amount=$amount";
        //cURL Request
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERPWD, $key_id.':'.$key_secret);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        //curl_setopt($ch, CURLOPT_CAINFO, dirname(__FILE__).'/ca-bundle.crt');
        return $ch;
    }   
        
    // callback method for registration

    public function callback() {        
        if (!empty($this->input->post('razorpay_payment_id')) && !empty($this->input->post('merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('razorpay_payment_id');
            $merchant_order_id = $this->input->post('merchant_order_id');
            $currency_code = 'INR';
            $amount = $this->input->post('merchant_total');
            $success = false;
            $error = '';
            try {    
                
                $ch = $this->get_curl_handle($razorpay_payment_id, $amount);
                //execute post
                
                $result = curl_exec($ch);
                //print_r($result);die;
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {
                    $response_array = json_decode($result, true);
                   // echo "<pre>";print_r($response_array);exit;
                        //Check success response
                        if ($http_status === 200 and isset($response_array['error']) === false) {
                            $success = true;
                        } else {
                            $success = false;
                            if (!empty($response_array['error']['code'])) {
                                $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                            } else {
                                $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                            }
                        }
                }
                //close connection
                curl_close($ch);
            } catch (Exception $e) {
                $success = false;
                $error = 'OPENCART_ERROR:Request to Razorpay Failed';
            }
            if ($success === true) {
                if(!empty($this->session->userdata('ci_subscription_keys'))) {
                    $this->session->unset_userdata('ci_subscription_keys');
                 }
                if (!$order_info['order_status_id']) {
                    //redirect($this->input->post('merchant_surl_id'));
                    //$this->session->set_userdata('school_id_for_payment',0);
                    $this->session->set_flashdata('transaction_details', $response_array);
                  
                    redirect('crest/payment_success_razorpay/', 'refresh');

                } else {
                    //redirect($this->input->post('merchant_surl_id'));
                    redirect('crest/payment_success_razorpay/', 'refresh');
                }

            } else {
                //redirect($this->input->post('merchant_furl_id'));
                redirect('crest/payment_error/', 'refresh');
            }
        } else {
            echo 'An error occured. Contact site administrator, please!';
        }
    }

      // callback method for challenge

    public function challenge_callback() {        
        if (!empty($this->input->post('razorpay_payment_id')) && !empty($this->input->post('merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('razorpay_payment_id');
            $merchant_order_id = $this->input->post('merchant_order_id');
            $currency_code = 'INR';
            $amount = $this->input->post('merchant_total');
            $success = false;
            $error = '';
            try {    
                
                $ch = $this->get_curl_handle($razorpay_payment_id, $amount);
                //execute post
                
                $result = curl_exec($ch);
                //print_r($result);die;
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {
                    $response_array = json_decode($result, true);
                   // echo "<pre>";print_r($response_array);exit;
                        //Check success response
                        if ($http_status === 200 and isset($response_array['error']) === false) {
                            $success = true;
                        } else {
                            $success = false;
                            if (!empty($response_array['error']['code'])) {
                                $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                            } else {
                                $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                            }
                        }
                }
                //close connection
                curl_close($ch);
            } catch (Exception $e) {
                $success = false;
                $error = 'OPENCART_ERROR:Request to Razorpay Failed';
            }
            if ($success === true) {
                if(!empty($this->session->userdata('ci_subscription_keys'))) {
                    $this->session->unset_userdata('ci_subscription_keys');
                 }
                if (!$order_info['order_status_id']) {
                    //redirect($this->input->post('merchant_surl_id'));
                    //$this->session->set_userdata('school_id_for_payment',0);
                    $this->session->set_flashdata('transaction_details', $response_array);
                  
                    redirect('crest/challenge_payment_success/', 'refresh');

                } else {
                    //redirect($this->input->post('merchant_surl_id'));
                    redirect('crest/challenge_payment_success/', 'refresh');
                }

            } else {
                //redirect($this->input->post('merchant_furl_id'));
                redirect('crest/challenge_payment_error/', 'refresh');
            }
        } else {
            echo 'An error occured. Contact site administrator, please!';
        }
    }  
    public function success() {
        $data['title'] = 'CREST Olympiads | Successful Transaction';  
        //$this->load->view('razorpay/success', $data);
    }  
    public function failed() {
        $data['title'] = 'CREST Olympiads | Failed Transaction';            
        //$this->load->view('razorpay/failed', $data);
    } 

         // callback method for slot update
    
    public function slot_callback() {        
        if (!empty($this->input->post('razorpay_payment_id')) && !empty($this->input->post('merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('razorpay_payment_id');
            $merchant_order_id = $this->input->post('merchant_order_id');
            $currency_code = 'INR';
            $amount = $this->input->post('merchant_total');
            $success = false;
            $error = '';
            try {    
                
                $ch = $this->get_curl_handle($razorpay_payment_id, $amount);
                //execute post
                
                $result = curl_exec($ch);
                //print_r($result);die;
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {
                    $response_array = json_decode($result, true);
                   // echo "<pre>";print_r($response_array);exit;
                        //Check success response
                        if ($http_status === 200 and isset($response_array['error']) === false) {
                            $success = true;
                        } else {
                            $success = false;
                            if (!empty($response_array['error']['code'])) {
                                $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                            } else {
                                $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                            }
                        }
                }
                //close connection
                curl_close($ch);
            } catch (Exception $e) {
                $success = false;
                $error = 'OPENCART_ERROR:Request to Razorpay Failed';
            }
            if ($success === true) {
                if(!empty($this->session->userdata('ci_subscription_keys'))) {
                    $this->session->unset_userdata('ci_subscription_keys');
                 }
                if (!$order_info['order_status_id']) {
                    //redirect($this->input->post('merchant_surl_id'));
                    //$this->session->set_userdata('school_id_for_payment',0);
                    $this->session->set_flashdata('transaction_details', $response_array);
                  
                    redirect('crest/slot_payment_success/', 'refresh');

                } else {
                    //redirect($this->input->post('merchant_surl_id'));
                    redirect('crest/slot_payment_success/', 'refresh');
                }

            } else {
                //redirect($this->input->post('merchant_furl_id'));
                redirect('crest/slot_payment_error/', 'refresh');
            }
        } else {
            echo 'An error occured. Contact site administrator, please!';
        }
    }  
}
?>