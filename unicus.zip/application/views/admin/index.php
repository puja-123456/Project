
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
</ol>

<div class="row">

    <?php echo $this->session->flashdata('message'); ?>

    <div class="col-md-12 text-center col-sm-6">
    
        <a href="<?php echo base_url(); ?>admin/dashboard">
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6">
                <div class="module-img"><i style="font-size:46px;color:#3c3c3c;" class="fa fa-dashboard"></i></div>
                <div class="module-hed">Dashboard</div>
            </div>
        </a>

        <a href="<?php echo base_url(); ?>admin/subcategorieslisting">
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6">
                <div class="module-img"><i style="font-size:46px;color:#3c3c3c;" class="fa fa-dashboard"></i></div>
                <div class="module-hed">Subjects</div>
            </div>
        </a>

        <a href="<?php echo base_url(); ?>admin/testimonialslisting">
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6">
                <div class="module-img"><i style="font-size:46px;color:#3c3c3c;" class="fa fa-dashboard"></i></div>
                <div class="module-hed">Testimonials</div>
            </div>
        </a>
        <a href="<?php echo base_url(); ?>admin/aboutlisting">
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6">
                <div class="module-img"><i style="font-size:46px;color:#3c3c3c;" class="fa fa-dashboard"></i></div>
                <div class="module-hed">CMS Pages</div>
            </div>
        </a>
        <a href="<?php echo base_url(); ?>admin/questionslisting">
            <div class="col-md-4 col-lg-3 col-sm-6 col-xs-6">
                <div class="module-img"><i style="font-size:46px;color:#3c3c3c;" class="fa fa-dashboard"></i></div>
                <div class="module-hed">Questions</div>
            </div>
        </a>
        </li>
    </div>
</div>